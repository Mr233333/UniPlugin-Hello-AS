package uni.dcloud.io.uniplugin_richalert.Info;

import com.alibaba.fastjson.JSONObject;

public class Person {
    public String label;
    public String content;
    public JSONObject attribute;
}
