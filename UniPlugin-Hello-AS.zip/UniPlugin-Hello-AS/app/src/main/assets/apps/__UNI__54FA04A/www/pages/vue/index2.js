
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"_button{margin-top:",[0,30],";margin-bottom:",[0,30],"}\n.",[1],"button-sp-area{margin:0 auto;width:60%}\n.",[1],"content{text-align:center;height:",[0,400],"}\n.",[1],"wrapper{-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center}\n.",[1],"button{width:200px;margin-top:30px;margin-left:20px;padding-top:20px;padding-bottom:20px;border:2px solid #458b00;background-color:#458b00}\n.",[1],"text{font-size:30px;color:#666;text-align:center}\n",])();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/vue/index2.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      